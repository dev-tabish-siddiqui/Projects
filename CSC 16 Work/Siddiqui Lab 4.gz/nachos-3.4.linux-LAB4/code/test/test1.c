#include "syscall.h"
int main(){
        int fid;
        char buf[10];
        Create("test_file.txt");
        fid = Open("test_file.txt");
        Write("hello world\n", 11, fid);
        Close(fid);
        fid = Open("test_file.txt");
        Read(buf,7,fid);
        Write(buf,7,ConsoleOutput);
        Close(fid);
}

