#include <map>
#include <synch.h>

using namespace std;
class PCB{
  public:

   PCB(Thread *thr, AddrSpace *addr, PCB *parent){
        this->iExitStatus = 0;
        this->sema = new Semaphore("sleep",0);
        this->mainthread = thr;
        this->addrspace = addr;
        this->pcbParent = parent;
        bAlive = true;
   }

   //* data members
   int iExitStatus;            	// the exit status
   Semaphore *sema;             // the semaphore for parent to sleep
   Thread *mainthread;          	// the main thread of the process
   AddrSpace *addrspace;     // the address space allocated for the process
   PCB *pcbParent;              	// the parent
   map<int,PCB*> childList;   // child list
   bool bAlive;
};

class ProcTable{
  public:
   ProcTable(){ };
   void insert(int id, PCB *pcb){
     procList[id] = pcb;
   }
   void remove(int id){
     procList.erase(id);
   }
   int size(){
     return procList.size();
   }
   PCB *find(int id){
        return procList[id];
   }
  private:
    map<int,PCB*> procList;
};

ProcTable procTable;


