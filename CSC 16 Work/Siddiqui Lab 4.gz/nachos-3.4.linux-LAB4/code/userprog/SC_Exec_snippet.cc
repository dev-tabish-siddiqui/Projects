else if((which==SyscallException) && (type == SC_Exec)){
        DEBUG('b', "Exec, initiated by user program.\n");
        int bufaddr= machine->ReadRegister(4);
        char *filename = (char *)malloc(100);
        for(int i=0;i<100;i++){
                int tempbuf = 0;
                machine->ReadMem(bufaddr+i,1,&tempbuf);
                filename[i] = (char)tempbuf;
	  	if(filename[i]==0) break; //stop copy when meets end
        }
        DEBUG('b',"SC_Exec called for %s\n", filename);


        //1. now open the file and allocate the address space
        OpenFile *executable = fileSystem->Open(filename);
        AddrSpace *space;
        if (executable == NULL) {
                printf("Unable to open file %s\n", filename);
                return;
        }
        space = new AddrSpace(executable);
        Thread *newthr = new Thread(filename);
        newthr->space = space;
        delete executable;                  // close file

	//2. set up the PCB!
	PCB *parentPCB = (PCB *)procTable.find((int)currentThread->space);
        PCB *pcbchild = new PCB(newthr,space,parentPCB);
        procTable.insert((int)space,pcbchild);
        if (parentPCB!=NULL) parentPCB->childList[(int)space]=pcbchild;

        //3. start the next thread
        machine->WriteRegister(2,(int)space);
        int curPC = machine->ReadRegister(PCReg);
        machine->WriteRegister(PCReg,curPC+4);
        newthr->Fork(exec_thread,0);
    }

