#include "bitmap.h"

class MemManager{
  public:
    MemManager(){
      numAvailablePage = NumPhysPages;
      memmap = new BitMap(NumPhysPages);
    }
    int AllocateFrame(){
      if(numAvailablePage == 0){
        fprintf(stderr,"no page available!\n");
        exit(2);
      }
      int ret = memmap->Find();
      ASSERT(ret!=-1);
      numAvailablePage--;
      return ret;
    }
    void FreeFrame(int pagenum){
      ASSERT(memmap->Test(pagenum));
      memmap->Clear(pagenum);
      numAvailablePage++;
    }
private:
     int numAvailablePage;
     BitMap *memmap;
};


