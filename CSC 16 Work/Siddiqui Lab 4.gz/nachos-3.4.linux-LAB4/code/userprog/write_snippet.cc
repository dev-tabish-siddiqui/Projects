else if((which==SyscallException) && (type == SC_Write)){
        DEBUG('b', "Write, initiated by user program.\n");       
        int bufaddr= machine->ReadRegister(4);
        int size= machine->ReadRegister(5);
        int id= machine->ReadRegister(6);
       char *strbuf = (char *)malloc(101);
       for(int i=0;i<100;i++){
                int tempbuf = 0;
                machine->ReadMem(bufaddr+i,1,&tempbuf);
                strbuf[i] = (char)tempbuf;
		  if(strbuf[i]==0) break;//break if end of string

       }
       write(id,strbuf,size);
        int curPC = machine->ReadRegister(PCReg);
        machine->WriteRegister(PCReg,curPC+4);
    }

